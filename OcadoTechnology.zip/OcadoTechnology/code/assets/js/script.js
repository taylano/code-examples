$(function(){

//VIDEO

	var videobox = $('#video');
	var videObj = $('video');
	var video = videObj[0];

	videObj.click(function(){
		video.play();
		videobox.addClass('full');	
		$(this).unbind('click');
	});

	videObj.bind('play', function(){
		videobox.addClass('full');	
	});
	videObj.bind('pause', function(){
		videobox.removeClass('full');	
	});
	videObj.bind('ended', function(){
		video.currentTime = 0;
		video.pause();
		videobox.removeClass('full');
	});


//POPUP	
	var peopleLink = $("a.people");
	var moreLink = $("a.more");
	var insertIn = $("div.popup > div");

	function linkClick(el){
		el.click(function(e){
			e.preventDefault();
			var href = $(this).attr("href");
			insertIn.load(href, function(){
				/*$('dl.tabs dt').click(function(e) {
					e.preventDefault();
					$('dl.tabs dt.active').removeClass('active');  
					$(this).addClass('active');  
				});*/
				$('dl.tabs dt').click(function(e) {
					e.preventDefault();
					$('dl.tabs dt.active').removeClass('active');
					$('dl.tabs dt + dd').css("display", "none");  
					$(this).addClass('active');  
					$('dl.tabs dt.active + dd').css("display", "block");
				});				
			});
		});
	}

	linkClick(peopleLink);
	linkClick(moreLink);

	var popupStatus = 0;

	function loadPopup(){
	  if(popupStatus==0){
	    $(".popupBg").css({
	      "opacity": "0.9"
	    });
	    $(".popupBg").fadeIn("fast");
	    $(".popup").fadeIn("fast");
	    popupStatus = 1;
	  }
	}

	function disablePopup(){
	  if(popupStatus==1){
	    $(".popupBg").fadeOut("fast");
	    $(".popup").fadeOut("fast");
	    popupStatus = 0;
	  }
	}

	function centerPopup(){
	  var windowWidth = document.documentElement.clientWidth;
	  var windowHeight = document.documentElement.clientHeight;
	  var popupHeight = $(".popup").outerHeight();
	  var popupWidth = $(".popup").outerWidth();
	  var scrollHeight = $(window).scrollTop();
	  $(".popup").css({
	    "position": "absolute",
	    "top": windowHeight/2-popupHeight/2 + scrollHeight,
	    "left": windowWidth/2-popupWidth/2
	  });
	}

	$(window).resize(function(){
		centerPopup();
	});

	function popClick(el){
                               el.bind("contextmenu",function(e){return false});
               el.click(function(e){
                 e.preventDefault();
                 centerPopup();
                 loadPopup();
                 if(sSize() === true){
                       $(window).scrollTop(0);
                 }
               });
       }
	popClick(peopleLink);
	popClick(moreLink);		
	      
	$("a.closePopup").click(function(e){
	  e.preventDefault();		
	  disablePopup();
	});
	$(".popupBg").click(function(){
	  disablePopup();
	});
	
	$(document).keypress(function(e){
	  if(e.keyCode==27 && popupStatus==1){
	    disablePopup();
	  }
	});


/*LINK TO MENU*/

	var linkToMn = $("a.linkToMn");
	var mn = $("#sitemap");

	linkToMn.bind('click', function(e){
		e.preventDefault();
		$('html, body').animate({scrollTop: mn.offset().top}, 1000);
	});


//GENERAL
	var ieload = $('.oldie #main');

	setTimeout(function(){
		ieload.css("visibility", "visible");
	}, 2000);

	function sSize(){
		if($(window).width() < '481'){
			return true;
		}
	}

	if (!Modernizr.video && document.body.style.scrollbar3dLightColor == undefined){
	   window.location = "index2.html";
	}

});






















