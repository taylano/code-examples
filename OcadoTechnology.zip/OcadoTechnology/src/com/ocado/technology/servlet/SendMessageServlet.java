package com.ocado.technology.servlet;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class DownloadFileServlet
 */
public class SendMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;		
	private static Logger log = Logger.getLogger(SendMessageServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendMessageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		boolean hasInputError = false;
		
		String name = request.getParameter("name");
		String candidateEmail = request.getParameter("email");
		String subject = request.getParameter("subject");
		String message = request.getParameter("message");
		
		InternetAddress candidateInternetAddress = null;
		
		String inputSource = "/contact/index.jsp";
			    
		if (name == null || "".equals(name)) {
			//Send error response
			request.setAttribute("nameError", "Name is a required Field");
			log.error("Name missing");
			hasInputError = true;
			//		
		}
		
		if (candidateEmail == null || "".equals(candidateEmail)) {
			//Send error response
			request.setAttribute("emailError", "Email is a required Field");
			log.error("Email missing");
			hasInputError = true;
		} else {
			try {
				//this validates if the email address is a valid email adderss and conforms to the RFC822
				candidateInternetAddress = new InternetAddress(candidateEmail);
			} catch (MessagingException me) {
				request.setAttribute("emailError", "Email is invalid");	
				log.error("Email invalid");
				hasInputError = true;
			}
		}

		if (message == null || "".equals(message)) {
			//Send error response
			request.setAttribute("messageError", "Message is a required Field");
			log.error("Message missing");
			hasInputError = true;
		}
		
		if (hasInputError) {
			getServletContext().getRequestDispatcher(inputSource).forward(request, response);	
		} else {
				
		
		//All valid, now send message
		sendMessage(candidateInternetAddress, subject, message);		
		getServletContext().getRequestDispatcher("/contact/response.html").forward(request, response);
		}
	}
	
	public void sendMessage(InternetAddress candidateEmail, String subject, String message) {

		String mailHost = getServletContext().getInitParameter("mailHost");
		String mailPort = getServletContext().getInitParameter("mailPort");
		String fromAddress = getServletContext().getInitParameter("fromAddress");
		String toAddress = getServletContext().getInitParameter("toAddress");
		Properties properties = new Properties();
		properties.put("mail.transport.protocol", "smtp");
		properties.put("mail.smtp.host", mailHost);
		properties.put("mail.smtp.port", mailPort);

		Transport transport = null;

		try {
		    			
			Session session = Session.getDefaultInstance(properties);
		    Message msg = new MimeMessage(session);
		    Address replyTos[] = new Address[1];
            replyTos[0] = candidateEmail;
            msg.setReplyTo(replyTos);            
		    msg.setFrom(new InternetAddress(fromAddress));		    
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));            
            msg.setSubject(subject);
            msg.setText(message);
            msg.setHeader("X-Mailer", "sendhtml");
                           
		    transport = session.getTransport("smtp");
		    
		    transport.connect();
		    transport.sendMessage(msg, msg.getAllRecipients());
		    
		    log.info("Message acknowledge from " + candidateEmail);
		    
		} catch (MessagingException e) {
			log.error("Could not send email to " + candidateEmail, e);			
		} finally {
		    if (transport != null) try { transport.close(); } catch (MessagingException e) { 
		    	log.error("Exception closing mail transport session ", e);
		    }
		}
	}
}
