/**
 * Created by taylan.oliver on 21/2/2017.
 */

 //The following JS unit test in Jasmine will check if a parameter of "SKU" is set within a anchor tag.
 //The purpose of the test is to ensure that an item can still be added to the basket even if the "SKU"
 //parameter is not available, an error log is then sent to the back-end for further investigation.   

describe("webshop.catalogue.Util.sendUpdateBasketRequest", function() {

    beforeEach(function() {
        mockWebshopCommon();
        mockDataLayer();
    });

    afterEach(function() {
        unmockWebshopCommon();
        unmockDataLayer();
    });

    it("Should report error using ServerLogger when SKU is not found in URL", function() {
        var domElement = jQ('<a href="http://www.ocado.com?=12345678">');
        webshop.catalogue.Util.sendUpdateBasketRequest.call(domElement,mockEventObj,null,null);
        var actualMsg = webshop.common.ServerLogger.error.calls.mostRecent().args[0];
        expect(actualMsg.substr(0, 6)).toEqual("Failed");
    });

    it("Should push ProductAddToBasketRule event to dataLayer when SKU is found in URL", function() {
        var domElement = jQ('<a href="http://www.ocado.com?sku=12345678">');
        webshop.catalogue.Util.sendUpdateBasketRequest.call(domElement,mockEventObj,null,null);
        expect(window.dataLayer[0]).toEqual({'event': 'ProductAddToBasketRule','PID': '12345678'});
    });

    var originalDataLayer = window.dataLayer;

    function mockDataLayer() {
        window.dataLayer = [];
    }

    function unmockDataLayer() {
        window.dataLayer = originalDataLayer;
    }

    var mockEventObj = {
        preventDefault: function () {
        }
    };

    var originalWebshopCommon = webshop.common;

    function mockWebshopCommon() {
        webshop.common = {
            ServerLogger: {
                error: jasmine.createSpy('logError')
            }
        };
    }

    function unmockWebshopCommon() {
        webshop.common = originalWebshopCommon;
    }
});