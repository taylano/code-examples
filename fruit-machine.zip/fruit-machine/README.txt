Run python server -  python -m SimpleHTTPServer 

Go to path :- http://localhost:8000

The game uses cookies to store the users credit total within a Json file, the user has to login with an email and password to play the game.

You can't navigate to the main game page without logging in, this is an extra security feature I thought might be useful.

Enjoy...:)

By:- Taylan Oliver



