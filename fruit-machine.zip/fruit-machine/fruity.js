
slotitem = new Array('0','1','2','3','4','5','6','7');

document.slots.bet.focus();
var credits = Cookies.get('credits');//gets the credit count from the creates Cookie 

startCredit = credits;
document.slots.credit.value=startCredit;

function stopplay () { //Displays final result and updates the json file with the final credit total
if (document.slots.credit.value < startCredit) {
		alert("You lost "+ (startCredit-document.slots.credit.value) +" credits.   ");
	}
else 	{
	alert("You gained "+ (document.slots.credit.value-startCredit) +" credits.   ");
}

}

function rollem () {//checks whether you have enough credit to spin the wheels...
if (document.slots.bet.value<1 || document.slots.bet.value == "") {
	alert("You cannot bet less that 1.   "); return;
}
if (Math.floor(document.slots.credit.value) < Math.floor(document.slots.bet.value)){
		alert("Your bet "+document.slots.bet.value+" is larger than your remaining credit "+document.slots.credit.value+".  "); 
		return;
	}
if (document.slots.bet.value>1) {
	document.slots.banner.value="Bet is "+document.slots.bet.value+" credits";
}
else {
	document.slots.banner.value="Bet is "+document.slots.bet.value+" credits";
}
counter=0;
spinem();

}

function spinem() {//The function generates a random number between 0 and 7 which is mapped to the corresponding image path,
					// we also set the amount of turns each wheel will do before stopping with a timeout... 
turns1=10+Math.floor((Math.random() * 10))
for (a=0;a<turns1;a++){
		document.slots.slot1.src="images/"+slotitem[a % 7]+".jpg"; 
	}
turns2=10+Math.floor((Math.random() * 10))
for (b=0;b<turns2;b++)
	{
		document.slots.slot2.src="images/"+slotitem[b % 7]+".jpg"; 
	}
turns3=10+Math.floor((Math.random() * 10))
for (c=0;c<turns3;c++)
	{
		document.slots.slot3.src="images/"+slotitem[c % 7]+".jpg"; 
	}
counter++;
if (counter<25) {
	setTimeout("spinem(counter);",50);} else {checkmatch();
	}

}

function checkmatch()	{ // This function checks for mathing fruit and displays whether you have won the jackpot, a pair or no match

if ((document.slots.slot1.src == document.slots.slot2.src) && (document.slots.slot1.src == document.slots.slot3.src)){
		document.slots.banner.value="3 of a kind - You've won the Jackpot "+Math.floor(document.slots.bet.value*10)+" credits.";
	 document.slots.credit.value=Math.floor(document.slots.credit.value)+Math.floor(document.slots.bet.value*10); 
	}

else if ((document.slots.slot1.src == document.slots.slot2.src) || (document.slots.slot1.src == document.slots.slot3.src) || (document.slots.slot2.src == document.slots.slot3.src)){
	document.slots.banner.value="A pair - You won "+Math.floor(document.slots.bet.value*2)+" credits.";
		 document.slots.credit.value = Math.floor(document.slots.bet.value*2) + Math.floor(document.slots.credit.value);
		}

else {
	document.slots.credit.value=document.slots.credit.value-document.slots.bet.value; 
		document.slots.banner.value="No match - You lost "+document.slots.bet.value+" credits.";
	}
}

$('.reset').click(function() {// Resets the game	
    location.reload();
});

$('a.logout').click(function() {// Logs the user out and removes the cookie from the browser	
    Cookies.clear('credits');
    window.location.href = "index.html";
});

