$(function(){
        $.getJSON('users.json',function(data){
      
            $.each(data.users,function(i,user){
                 $('button').one('click', function () {
                 	var email = $('form').find('input[name="email"]').val();
                 	var password = $('form').find('input[name="password"]').val();

					if(email == user.email && password == user.password){

							Cookies.set('credits', user.credits);
						
						window.location.href = "slots.html";
					} else {						
						$('.input-group-addon').css({'color':'red'});
					}				  
				});

            });
        }).error(function(){
            console.log('error No Json data');
        });
    });

