// The following code will add items to the main trolley using a single button click populated with suggested items to start your shop
// The Ajax call simply sends a request using a click function to the server with all of the SKU numbers in an array, it then waits for a response
// If the SKUs do not exist it will throw an error and stop the the process, otherwise it will go ahead and add all of the items to the basket   
var optiClicked=0; optiProds = [['78914011','57294011','44855011','14578011','50434011','18842011','24608011','19015011','83706011','57453011','18845011','10276011','12282011','10881011','15651011','77760011','63028011','44847011','19028011','65233011','44858011']];

function optiAddProds(optiP){
  jQ.each(optiProds[optiP-1], function(i,optiProdsValue){
    jQ.ajax({
          url: "/webshop/addToBasket.do",
          type: "post",
          data: {xproduct:'41328011', xparentContainer:'LOG_IN_TOP_OFF#productDetails-41328011', desc:'Cheestrings+Original', parentContainer:'LOG_IN_TOP_OFF', originalQuantity:'1', isSlotSub:'null', isCowGift:'false', quantityUpdateAddedFromSection:'FAVOURITES', analyticsPageType:'HOMEPAGE', pageComponentIdForBQU:'1420023385915.OCADO133-4', sku:optiProdsValue, quantity:'1', showDescription:'false'},
          success: function(){
               console.log('submitted successfully');
          },
          error:function(){
              console.log('there is error while submit');
          }  
      });
  });
  setTimeout(function(){
window.location.href='/webshop/displaySmartBasket.do'; 
  }, 1200);
}

jQ("button#optiList-1").on( "click", function(){
  optiClicked++;
  if(optiClicked==1){
optiAddProds(this.id.slice(9));
  }
});