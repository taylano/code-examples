$(document).ready(function() {
	
	area = '';
    
    $('.map').hide();    
    	
	 $('.close').click(function(){ 
	 area = '';      
            $('.areaOne').hide();
			$(".overlay").hide();
		$(".textArea").css('display','block').fadeIn();
		$(".textArea1").css('display','none');
		$(".textArea2").css('display','none');
		$(".textArea3").css('display','none');
		$(".areaOne").css('z-index','70');	                 
    });
		
	 $('.close2').click(function(){  
	 area = '';     
            $('.areaTwo').hide(); 
		$(".textArea").css('display','block').fadeIn();
		$(".textArea1").css('display','none');
		$(".textArea2").css('display','none');
		$(".textArea3").css('display','none');
		$(".areaTwo").css('z-index','70');		                
    });
	
	
	$('.close3').click(function(){ 
	area = '';      
            $('.areaThree').hide(); 
		$(".textArea").css('display','block').fadeIn();
		$(".textArea1").css('display','none');
		$(".textArea2").css('display','none');
		$(".textArea3").css('display','none');
		$(".areaThree").css('z-index','70');	                
    });
      
	$("#B8_DESPATCH").click( function() {
		area = 'B8_DESPATCH';
		$(".overlay").css("background-image", "url(css/assets/B8_DESPATCH.png)").fadeIn(100);
		$(".areaOne").css('display','block').fadeIn(100);
		$(".areaTwo").css('display','none');
		$(".areaThree").css('display','none');
		$(".areaOne").css('z-index','999');	
		
		$(".textArea").css('display','none');
		$(".textArea1").css('display','block').fadeIn(100);
		$(".textArea2").css('display','none');	
		$(".textArea3").css('display','none');		
	});
		
	$("#B8_DESPATCH").mouseenter( function() {
		$(".overlay").css("background-image", "url(css/assets/B8_DESPATCH.png)").fadeIn(100);
		$(".areaOne").css('display','block').fadeIn(100);	
	});
	
	$("#B8_DESPATCH").mouseleave( function() {				
		if(area != 'B8_DESPATCH'){
			$(".overlay").hide();
			$(".areaOne").css('display','none');
			}
	
	});
		
	$("#B3_TOTE_PALLET_STORAGE").click( function() {
		area = 'B3_TOTE_PALLET_STORAGE';	
		$(".areaTwo").css('display','block').fadeIn(100);
		$(".areaOne").css('display','none');
		$(".areaThree").css('display','none');	
		$(".areaTwo").css('z-index','999');	
		
		$(".textArea").css('display','none');
		$(".textArea1").css('display','none');
		$(".textArea2").css('display','block').fadeIn(100);
		$(".textArea3").css('display','none');		
	});
	
	$("#B3_TOTE_PALLET_STORAGE").mouseenter( function() {
		$(".overlay").css("background-image", "url(css/assets/B3_TOTE_PALLET_STORAGE.png)").fadeIn(100);
		$(".areaTwo").css('display','block').fadeIn(100); 	
	});
	
	$("#B3_TOTE_PALLET_STORAGE").mouseleave( function() {		
		if(area != 'B3_TOTE_PALLET_STORAGE'){
			$(".overlay").hide(); 
			$(".areaTwo").css('display','none');
			}	
	});
	
	
	$("#B5_PALLET_STORAGE").click( function() {
		area = 'B5_PALLET_STORAGE';	
		$(".areaThree").css('display','block').fadeIn(100);	
		$(".areaOne").css('display','none');
		$(".areaTwo").css('display','none');
		$(".areaThree").css('z-index','999');
		
		$(".textArea").css('display','none');
		$(".textArea1").css('display','none');
		$(".textArea2").css('display','none');
		$(".textArea3").css('display','block').fadeIn(100);
				
	});
	
	$("#B5_PALLET_STORAGE").mouseenter( function() {
		$(".overlay").css("background-image", "url(css/assets/B5_PALLET_STORAGE.png)").fadeIn(100); 
		$(".areaThree").css('display','block').fadeIn(100);	
	});
	
	$("#B5_PALLET_STORAGE").mouseleave( function() {		
		if(area != 'B5_PALLET_STORAGE'){
			$(".overlay").hide();
			$(".areaThree").css('display','none'); 	
			}
	});
	
	
	
});
