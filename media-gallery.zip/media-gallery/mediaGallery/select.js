var mysql      = require('mysql');
//var connection = mysql.createConnection({
  //host     : 'sql8.freemysqlhosting.net',
  //user     : 'sql8155871',
  //password : 'WBTIyVqIZs',
  //database : 'tester'
//});

var connection = mysql.createConnection({
  host     : 'localhost',
  socketPath : 'sql8.freemysqlhosting.net',
  user     : 'sql8155871',
  password : 'WBTIyVqIZs',
  database : 'tester',
  port     : '3306'
});

connection.connect(function(err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }

  console.log('connected as id ' + connection.threadId);
});