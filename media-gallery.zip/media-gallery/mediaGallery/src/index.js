var React = require('react');
var ReactDOM = require('react-dom');

import Header from './components/header';
import Gallery from './components/gallery';
import Footer from './components/footer';

class App extends React.Component {	 
	render() {
		return (
			<div className="Wrapper">			
					<Header />
					<Gallery />										
					<Footer />
			</div>						
			)
	}
}

ReactDOM.render(<App />, document.getElementById('react-app'));

