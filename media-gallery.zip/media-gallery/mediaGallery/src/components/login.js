var React = require('react');
var ReactDOM = require('react-dom');

var Login = React.createClass({

  getInitialState: function () {
    return { Username: '', Password: '' };    
  },

  handleUsernameChange: function(e) {
    this.setState({Username: e.target.value});
  },

  handlePasswordChange: function(e) {
    this.setState({Password: e.target.value});
  },

  handleClick: function(event) {    
   event.preventDefault(event);

    var User = this.state.Username;    
    var Password = this.state.Password;

    if(User == "taylano" && Password == "tester"){   

      var removeLogin = document.getElementsByClassName("login");
      removeLogin[0].parentNode.removeChild(removeLogin[0]);      
      var displayNameHeader = document.getElementsByClassName("userNameShow");
      displayNameHeader[0].innerHTML += "Hi " + User;

    } else {
      console.log("Access Denied");
    } 

  },
   render: function() {
    return (
      <div className="regForm">        
          <div className="login">         
              <input type="text" name="Username" placeholder="Username" value={this.state.Username} onChange={this.handleUsernameChange} />
              <br />
              <input type="Password" name="Password" placeholder="Password" value={this.state.Password} onChange={this.handlePasswordChange} />
              <br />
              <input
                type="button"
                value="Login"
                onClick={this.handleClick} />
          </div>
      </div>
    );
  }    
});

export default Login;
