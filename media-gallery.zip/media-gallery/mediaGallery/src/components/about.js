var React = require('react');
var ReactDOM = require('react-dom');

var About = React.createClass({	

	render() {
		return (
				<div className="about">{/*LoggedIn() == true && <h1>About</h1>*/}</div>
				)			
			}

});

export default About;