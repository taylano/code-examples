var React = require('react');
var ReactDOM = require('react-dom');

class Header extends React.Component {
	constructor (){
		super();
		this.state = {logo: "Gallery", slideshow: "Slideshow", share: "Share", close: "X"};		
	} 
	render() {
		return (
			<div className="headerArea navbar-header">
				<h1 className="title"></h1>
				<p className="userNameShow"></p>
				<a href="#" className="logo"><img src="images/assets/svg icons/Intu-logo-wordmark.svg" />Gallery</a>
				<ul className="nav">
						<li className="Item-2"><a href="#">{this.state.slideshow}</a></li>
						<li className="Item-3"><a href="#">{this.state.share}</a></li>
						<li className="Item-4"><a href="#"><img src="images/assets/svg icons/disclosure-indicator.svg" /></a></li>						
					</ul>					
			</div>
  
    )
	}
}

export default Header;