var React = require('react');
var ReactDOM = require('react-dom');
             
var Gallery = React.createClass({
    render() {
        return (
            <div className="sliderBlock">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    			<script src="src/scripts/jquery.bxslider.js"></script>    			 	
            <ul className="bxslider">
  				<li><img src="images/assets/big-gallery-images-assets/Two Tone Coat (La Redoute).jpg" /></li>
  				<li><img src="images/assets/big-gallery-images-assets/topshop-orange-skirt.jpg" /></li>
  				<li><img src="images/assets/big-gallery-images-assets/Layer 1.jpg" /></li>
			</ul>
				<div className="mainTitle">
			   		<p>HOW TO NAIL PARTY DRESSING</p>
			   		<h2>The two-tone coat</h2>
			   		<pager>1 of 9</pager>
			   </div>      		            		
            </div>
        );
    }
});

export default Gallery;