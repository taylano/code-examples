var React = require('react');
var ReactDOM = require('react-dom');

class Footer extends React.Component {
	render() {
		return (
				<div className="footer">

					<div className="sub-nav">
						<div className="inner">
							<div className="left"><a href="#" className="description active"><img src="images/assets/svg icons/Line + Line + Line.svg" />Description</a></div>
							<div className="right"><a href="#" className="products"><img src="images/assets/svg icons/Group.svg" />Thumbnails</a></div>
							<div className="center"><a href="#" className="thumbnails"><img src="images/assets/svg icons/Shape + Shape.svg" />Products</a></div>
							<div className="clear"></div>
						</div>
					</div>

					<p>The versatile colour-block will bridge the gap between deepest, darkest winter and the start of spring. The versatile colour-block will bridge ...</p>
				</div>
			)
	}
}

export default Footer;