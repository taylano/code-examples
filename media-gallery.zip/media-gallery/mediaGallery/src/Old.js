var React = require('react');
var ReactDOM = require('react-dom');

//Header
var listItemElement1 = React.DOM.li({ className:'item-1 active', key:'item-1'}, 'product');
var listItemElement2 = React.DOM.li({ className:'item-2', key:'item-2'}, 'about');
var listItemElement3 = React.DOM.li({ className:'item-3', key:'item-3'}, 'portfolio');
var listItemElement4 = React.DOM.li({ className:'item-4', key:'item-4'}, 'team');
var listItemElement5 = React.DOM.li({ className:'item-5', key:'item-5'}, 'contact');
var logo = React.DOM.h1({ className:'logo', key:'logo'}, 'basement');
var menuButton = React.DOM.a({ className:'menu', href:'#', key:'menu'}, 'menu');
var reactFragment = [listItemElement1, listItemElement2, listItemElement3, listItemElement4, listItemElement5];
var nav = React.DOM.ul({ className: 'nav navbar-nav'}, reactFragment);
var navbarCollapse = React.DOM.div({ className: 'navbar-collapse collapse'}, nav, logo, menuButton);

var paraMore = React.DOM.p({ className:'paraMore', key:'paraMore'}, 'Nam elementum rutrum ipsum sit amet luctus. Sed libero turpis, eleifend in quam sed, vestibulum vulputate ante.');
var moreInfoLink = React.DOM.a({ className:'more', href:'#', key:'more'}, 'more info');
var moreInfo = React.DOM.div({ className: 'moreInfo', key:'more info'}, paraMore, moreInfoLink);

//Content
var mainTitle = <h2 className="mainTitle">Etiam nisl dui, ultricies quis turpis quis, dapibus finibus tortor</h2>;
var sideBar = <div className="sideBar">
<h3>Fantasic Service, I'm excited!</h3>
<p>Mauris eu finibus diam. Quisque accumsan aliquet dictum. Aenean interdum tortor vitae elit elementum, et interdum tortor imperdiet. Duis sed justo ultrices, aliquam nisi sit amet, interdum justo.</p>
<h4>Taylan Oliver</h4>
<p>Citizens Advice</p>
<p>Lead Front End UX Developer</p>
</div>;
var textBlock = <div className="textBlock ">
	<h3>Ut sit amet scelerisque ex, sit amet mattis sapien</h3>
	<p>Mauris eu finibus diam. Quisque accumsan aliquet dictum. Aenean interdum tortor vitae elit elementum, et interdum tortor imperdiet. Duis sed justo ultrices, aliquam nisi sit amet, interdum justo. 
	</p>
	<p>Mauris eu finibus diam. Quisque accumsan aliquet dictum. Aenean interdum tortor vitae elit elementum, et interdum tortor imperdiet. Duis sed justo ultrices, aliquam nisi sit amet, interdum justo.</p>
	<h3>Ut sit amet scelerisque ex, sit amet mattis sapien. Proin convallis libero porta, mattis quam vitae</h3>
	<p>Pellentesque porttitor urna a nisi sodales, ac condimentum mauris auctor. In efficitur velit ut eros porttitor eleifend. In tempor diam at urna finibus, vitae lobortis sem tincidunt. Donec ac elementum orci.</p>
</div>;
var mainContent = React.DOM.div({className: 'content', key: 'content'}, mainTitle, sideBar, textBlock);

//Footer
var footer = <div className="footer">
<span className="footerImg"></span>
<div className="footerList">
	<ul className="productList">
		<li>PRODUCT</li>
		<li>Features</li>
		<li>Promo</li>
		<li>Download</li>
	</ul>
	<ul className="contactList">
		<li>CONTACT</li>
		<li>Find us</li>
		<li>FAQ</li>
		<li>Help</li>
	</ul>
	<ul className="socialList">
		<li>FOLLOW US</li>
		<li>
			<a className="facebook"></a>
			<a className="twitter"></a>
			<a className="dribbble"></a>
		</li>		
	</ul>
</div>
</div>;

//render block
var homepage = React.DOM.div({ className:'container', key:'container'}, navbarCollapse, moreInfo, mainContent, footer);
ReactDOM.render(homepage, document.getElementById('react-app'));
